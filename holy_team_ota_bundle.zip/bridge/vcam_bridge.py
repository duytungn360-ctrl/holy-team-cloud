"""
HOLY TEAM Virtual Camera Bridge (Windows DirectShow -> OBS Studio & TikTok Live Studio)
Nhận khung hình GPU đã làm đẹp qua Local WebSocket và đẩy thẳng vào pyvirtualcam ở chuẩn dọc 9:16 hoặc 16:9.
"""
import asyncio
import json
import sys
import cv2
import numpy as np
import pyvirtualcam
import websockets

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 19525
TARGET_W = int(sys.argv[2]) if len(sys.argv) > 2 else 1080
TARGET_H = int(sys.argv[3]) if len(sys.argv) > 3 else 1920


def emit(status: str, message: str, device: str = ""):
    payload = {"status": status, "message": message, "device": device}
    print(json.dumps(payload, ensure_ascii=False), flush=True)


async def main():
    cam = None
    try:
        cam = pyvirtualcam.Camera(
            width=TARGET_W,
            height=TARGET_H,
            fps=60,
            fmt=pyvirtualcam.PixelFormat.BGR,
        )
        emit(
            "ready",
            f"Đã bật Camera ảo ({cam.device}) ở chuẩn {TARGET_W}x{TARGET_H} 60FPS",
            cam.device,
        )
    except Exception as exc:
        emit(
            "error",
            "Chưa tìm thấy Driver Camera ảo trên Windows. Hãy cài OBS Studio (28+) hoặc UnityCapture để dùng chế độ Webcam ảo, hoặc dùng nút 'Đẩy Sang OBS 1-Click' không cần driver! Chi tiết: "
            + str(exc),
        )
        return

    latest_frame = np.zeros((TARGET_H, TARGET_W, 3), dtype=np.uint8)

    async def handle_client(websocket):
        nonlocal latest_frame
        async for msg in websocket:
            if isinstance(msg, bytes):
                arr = np.frombuffer(msg, dtype=np.uint8)
                bgr = cv2.imdecode(arr, cv2.IMREAD_COLOR)
                if bgr is not None:
                    if bgr.shape[1] != TARGET_W or bgr.shape[0] != TARGET_H:
                        bgr = cv2.resize(
                            bgr, (TARGET_W, TARGET_H), interpolation=cv2.INTER_LINEAR
                        )
                    latest_frame = bgr
                    cam.send(latest_frame)

    async with websockets.serve(
        handle_client, "127.0.0.1", PORT, max_size=8 * 1024 * 1024
    ):
        while True:
            await asyncio.sleep(1.0)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
