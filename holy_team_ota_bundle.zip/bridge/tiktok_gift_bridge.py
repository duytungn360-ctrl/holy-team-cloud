"""
HOLY TEAM Local TikTok Live Gift Catcher (Chạy 100% trên máy Idol — Không cần VPS!)
- Kết nối trực tiếp vào phòng live công khai qua @username (không cần mật khẩu / cookie)
- Bắt tức thì gói WebcastGiftMessage ngay từ nhịp chạm x1 đầu tiên (0 độ trễ chờ kết thúc combo!)
"""
import asyncio
import json
import sys

sys.stdout.reconfigure(encoding="utf-8")


def emit(event_type: str, **kwargs):
    payload = {"event": event_type, **kwargs}
    print(json.dumps(payload, ensure_ascii=False), flush=True)


async def run_catcher(raw_username: str):
    username = raw_username.strip().lstrip("@")
    if not username:
        emit("error", message="Vui lòng nhập ID kênh TikTok hợp lệ!")
        return

    try:
        from TikTokLive import TikTokLiveClient
        from TikTokLive.events import (
            CommentEvent,
            ConnectEvent,
            DisconnectEvent,
            GiftEvent,
            LiveEndEvent,
        )
    except Exception as exc:
        emit("fallback_needed", message=f"Thiếu thư viện TikTokLive: {exc}")
        return

    emit("connecting", message=f"Đang kết nối vào phòng live @{username}...")

    client = TikTokLiveClient(unique_id=f"@{username}")
    streak_tracker: dict[str, int] = {}

    @client.on(ConnectEvent)
    async def on_connect(event: ConnectEvent):
        emit(
            "connected",
            username=username,
            roomId=str(getattr(client, "room_id", "")),
            message=f"Đang bắt quà trực tiếp phòng @{username}",
        )

    @client.on(DisconnectEvent)
    async def on_disconnect(_event: DisconnectEvent):
        emit("disconnected", message=f"Đã ngắt kết nối phòng @{username}")

    @client.on(LiveEndEvent)
    async def on_live_end(_event: LiveEndEvent):
        emit("ended", message=f"Phiên live của @{username} đã kết thúc")

    @client.on(CommentEvent)
    async def on_comment(event: CommentEvent):
        try:
            user = getattr(event, "user", None)
            sender = (
                getattr(user, "nickname", None)
                or getattr(user, "unique_id", None)
                or "Khán giả"
            )
            text = str(getattr(event, "comment", "") or "").strip()
            if text:
                emit(
                    "comment",
                    sender=sender,
                    comment=text,
                )
        except Exception:
            pass

    @client.on(GiftEvent)
    async def on_gift(event: GiftEvent):
        try:
            user = getattr(event, "user", None)
            sender = (
                getattr(user, "nickname", None)
                or getattr(user, "unique_id", None)
                or "Khán giả"
            )
            uid = str(getattr(user, "id", sender))

            gift = getattr(event, "gift", None)
            gift_id = str(getattr(gift, "id", "0"))
            gift_name = getattr(gift, "name", None) or "Quà tặng"
            diamonds = int(getattr(gift, "diamond_count", 1) or 1)
            repeat_count = int(getattr(event, "repeat_count", 1) or 1)
            streaking = bool(getattr(event, "streaking", False))

            icon_url = ""
            for img_attr in ("image", "icon", "preview_image"):
                img_obj = getattr(gift, img_attr, None)
                urls = getattr(img_obj, "url_list", None) if img_obj else None
                if urls and len(urls) > 0:
                    icon_url = str(urls[0])
                    break

            key = f"{uid}:{gift_id}"
            prev_count = streak_tracker.get(key, 0)

            # Kích hoạt ngay ở phát x1 đầu tiên, và cập nhật mượt khi tăng combo (không bắn trùng lặp kết thúc combo!)
            if streaking:
                if repeat_count <= prev_count:
                    return
                streak_tracker[key] = repeat_count
                delta_count = repeat_count - prev_count
            else:
                if prev_count >= repeat_count and prev_count > 0:
                    streak_tracker.pop(key, None)
                    return
                delta_count = max(1, repeat_count - prev_count)
                streak_tracker.pop(key, None)

            emit(
                "gift",
                sender=sender,
                giftId=gift_id,
                giftName=gift_name,
                giftIconUrl=icon_url,
                diamonds=diamonds,
                repeatCount=repeat_count,
                deltaCount=delta_count,
                totalDiamonds=diamonds * repeat_count,
            )
        except Exception as err:
            emit("log", message=f"Gift parse note: {err}")

    try:
        await client.start()
    except Exception as exc:
        err_name = type(exc).__name__.lower()
        err_str = str(exc)
        err_low = err_str.lower()
        is_offline = (
            "offline" in err_name
            or "offline" in err_low
            or "not found" in err_low
            or "usernotfound" in err_name
            or "not currently live" in err_low
        )
        if is_offline:
            emit(
                "offline",
                message=f"Kênh @{username} hiện chưa bật Livestream (Anh có thể bấm các nút Test Thử Quà ngay bên dưới!)",
            )
        else:
            emit("fallback_needed", username=username, message=err_str)


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else ""
    try:
        asyncio.run(run_catcher(target))
    except KeyboardInterrupt:
        pass
